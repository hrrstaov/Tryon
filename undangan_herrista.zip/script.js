// Countdown
const eventDate = new Date('2025-12-20T00:00:00').getTime();
const cd = document.getElementById('countdown');
if(cd){
  setInterval(()=>{
    const now = new Date().getTime();
    const diff = eventDate - now;
    if(diff<=0){cd.innerText='Hari ini!'}
    else{
      const d=Math.floor(diff/(1000*60*60*24));
      const h=Math.floor((diff%(1000*60*60*24))/(1000*60*60));
      const m=Math.floor((diff%(1000*60*60))/(1000*60));
      const s=Math.floor((diff%(1000*60))/1000);
      cd.innerText=`${d}h ${h}j ${m}m ${s}d`;
    }
  },1000);
}